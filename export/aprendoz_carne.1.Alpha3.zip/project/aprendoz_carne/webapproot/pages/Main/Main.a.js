dojo.declare("Main", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
// shwo picture
peopledojoGrid1Select: function(inSender) {
var codigop= this.peopledojoGrid1.selectedItem.data.codigo;
this.fotoStd.setSource("http://www.rochester.edu.co/fotosestudiantes/"+codigop+".Jpeg");
},
// save suceso
Registrar_SucesoClick: function(inSender) {
var idpersona= this.peopledojoGrid1.selectedItem.data.idpersona;
var tipo= this.tipoSuceso.getDataValue();
var now = new Date().getTime();
this.varInsertLog.setValue("persona.idPersona", idpersona);
this.varInsertLog.setValue("tipoFalla.idTipoFalla", tipo);
this.varInsertLog.setValue("fechaCreacion", now);
this.insertLogForm.setDataSet(this.varInsertLog);
this.insertLogForm.insertData();
},
// getting familiar group details
Registrar_SucesoClick1: function(inSender) {
var idpersona= this.peopledojoGrid1.selectedItem.data.idpersona;
var idgrupo= this.peopledojoGrid1.selectedItem.data.idgrupito;
console.log(idpersona+" "+idgrupo);
this.getParentsInfo.input.setValue("pgrupo", idgrupo);
this.getParentsInfo.input.setValue("ppersona", idpersona);
this.getParentsInfo.update();
},
getParentsInfoSuccess: function(inSender, inDeprecated) {
var json= main.getParentsInfo.getItem(0);
var nombreCompleto= this.peopledojoGrid1.selectedItem.data.fullname;
var fechaCompleta= this.dateTime1.getDisplayValue();
var correopadre= json.data.correopapa;
var correomadre= json.data.correomama;
var motivo= this.tipoSuceso.getDisplayValue();
if(confirm("¿Esta seguro de enviar la notificación a los padres?")){
this.sendMailsParents.input.setValue("motivo", motivo);
this.sendMailsParents.input.setValue("alumno", nombreCompleto);
this.sendMailsParents.input.setValue("correopadre", correopadre);
this.sendMailsParents.input.setValue("correomadre", correomadre);
this.sendMailsParents.input.setValue("fechahora", fechaCompleta);
this.sendMailsParents.update();
}else{
alert("Operación cancelada.");
}
},
peopledojoGrid1Select2: function(inSender) {
this.Registrar_Suceso.enable();
},
_end: 0
});

Main.widgets = {
monthsVar: ["wm.Variable", {"isList":true,"json":"[{name: \"January\", dataValue: 0}, {name: \"February\", dataValue: 1},{name: \"March\", dataValue: 2},{name: \"April\", dataValue: 3},{name: \"May\", dataValue: 4},{name: \"June\", dataValue: 5},{name: \"July\", dataValue: 6},{name: \"August\", dataValue: 7},{name: \"September\", dataValue: 8},{name: \"October\", dataValue: 9},{name: \"November\", dataValue: 10},{name: \"December\", dataValue: 11}]","type":"EntryData"}, {}],
varTemplateUsername: ["wm.ServiceVariable", {"autoUpdate":true,"operation":"getUserName","service":"securityService","startUpdate":true}, {}, {
input: ["wm.ServiceInput", {"type":"getUserNameInputs"}, {}]
}],
varTemplateLogout: ["wm.LogoutVariable", {}, {}, {
input: ["wm.ServiceInput", {"type":"logoutInputs"}, {}]
}],
varTemplateLogout1: ["wm.LogoutVariable", {}, {}, {
input: ["wm.ServiceInput", {"type":"logoutInputs"}, {}]
}],
searchUsersDetails: ["wm.ServiceVariable", {"inFlightBehavior":"executeLast","operation":"getDetailsUser","service":"aprendoz_desarrolloDB"}, {}, {
input: ["wm.ServiceInput", {"type":"getDetailsUserInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"4","targetProperty":"idsy"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"searchBox.dataValue","targetProperty":"search"}, {}]
}]
}]
}],
varInsertLog: ["wm.Variable", {"type":"com.aprendoz_desarrollodb.data.LogIngresoCarne"}, {}],
lsTipoSucesos: ["wm.LiveVariable", {"inFlightBehavior":"executeLast","type":"com.aprendoz_desarrollodb.data.TipoFalla"}, {}, {
liveView: ["wm.LiveView", {"dataType":"com.aprendoz_desarrollodb.data.TipoFalla","view":[
{"caption":"IdTipoFalla","sortable":true,"dataIndex":"idTipoFalla","type":"java.lang.Integer","displayType":"Number","required":true,"readonly":true,"includeLists":true,"includeForms":true,"order":0,"subType":null},
{"caption":"TipoFalla","sortable":true,"dataIndex":"tipoFalla","type":"java.lang.String","displayType":"Text","required":true,"readonly":false,"includeLists":true,"includeForms":true,"order":1,"subType":null}
]}, {}]
}],
templateUsernameVar: ["wm.ServiceVariable", {"autoUpdate":true,"operation":"getUserName","service":"securityService","startUpdate":true}, {}, {
input: ["wm.ServiceInput", {"type":"getUserNameInputs"}, {}]
}],
templateLogoutVar: ["wm.LogoutVariable", {}, {}, {
input: ["wm.ServiceInput", {"type":"logoutInputs"}, {}]
}],
registroInsertado: ["wm.NavigationCall", {"operation":"showToast"}, {}, {
input: ["wm.ServiceInput", {"type":"showToastInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"Evento guardado exitosamente!\"","targetProperty":"content"}, {}],
wire1: ["wm.Wire", {"expression":"3000","targetProperty":"duration"}, {}],
wire2: ["wm.Wire", {"expression":"\"Success\"","targetProperty":"cssClasses"}, {}],
wire3: ["wm.Wire", {"expression":"\"bottom center\"","targetProperty":"dialogPosition"}, {}]
}]
}]
}],
errorInsercion: ["wm.NavigationCall", {"operation":"showToast"}, {}, {
input: ["wm.ServiceInput", {"type":"showToastInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"Error al registrar el evento. Por favor comuniquese con Sistemas.\"","targetProperty":"content"}, {}],
wire1: ["wm.Wire", {"expression":"3000","targetProperty":"duration"}, {}],
wire2: ["wm.Wire", {"expression":"\"Error\"","targetProperty":"cssClasses"}, {}],
wire3: ["wm.Wire", {"expression":"\"bottom center\"","targetProperty":"dialogPosition"}, {}]
}]
}]
}],
getParentsInfo: ["wm.ServiceVariable", {"inFlightBehavior":"executeLast","operation":"orientacionInvolucradosGrupoFamiliar","service":"aprendoz_desarrolloDB"}, {"onSuccess":"getParentsInfoSuccess"}, {
input: ["wm.ServiceInput", {"type":"orientacionInvolucradosGrupoFamiliarInputs"}, {}]
}],
sendMailsParents: ["wm.ServiceVariable", {"inFlightBehavior":"executeLast","operation":"enviarNotificacionFaltaGrave","service":"enviarMail"}, {"onSuccess":"successEnvioMail","onError":"errorEnvioMail"}, {
input: ["wm.ServiceInput", {"type":"enviarNotificacionFaltaGraveInputs"}, {}]
}],
successEnvioMail: ["wm.NavigationCall", {"operation":"showToast"}, {}, {
input: ["wm.ServiceInput", {"type":"showToastInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire1: ["wm.Wire", {"expression":"4000","targetProperty":"duration"}, {}],
wire3: ["wm.Wire", {"expression":"\"top center\"","targetProperty":"dialogPosition"}, {}],
wire: ["wm.Wire", {"expression":"\"Notificación enviada exitosamente.\"","targetProperty":"content"}, {}],
wire2: ["wm.Wire", {"expression":"\"Success\"","targetProperty":"cssClasses"}, {}]
}]
}]
}],
errorEnvioMail: ["wm.NavigationCall", {"operation":"showToast"}, {}, {
input: ["wm.ServiceInput", {"type":"showToastInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"Notificación no enviada, por favor comuníquese con el Area de Sistemas y reporte el inconveniente.\"","targetProperty":"content"}, {}],
wire1: ["wm.Wire", {"expression":"5000","targetProperty":"duration"}, {}],
wire2: ["wm.Wire", {"expression":"\"Warning\"","targetProperty":"cssClasses"}, {}],
wire3: ["wm.Wire", {"expression":"\"top center\"","targetProperty":"dialogPosition"}, {}]
}]
}]
}],
loadingDialog1: ["wm.LoadingDialog", {"caption":"Consultando información...","serviceVariableToTrack":["searchUsersDetails"]}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"peopledojoGrid1","targetProperty":"widgetToCover"}, {}]
}]
}],
layoutBox1: ["wm.Layout", {"horizontalAlign":"left","padding":"50","styles":{},"verticalAlign":"top"}, {}, {
SearchListDetail: ["wm.Panel", {"height":"100%","horizontalAlign":"left","styles":{},"verticalAlign":"top","width":"100%"}, {}, {
searchBarPanel: ["wm.Panel", {"_classes":{"domNode":["toolbar"]},"height":"36px","layoutKind":"left-to-right","styles":{"backgroundColor":"#d3d3d3"},"verticalAlign":"middle","width":"100%"}, {}, {
searchBox: ["wm.Text", {"changeOnKey":true,"dataValue":undefined,"displayValue":"","height":"30px","margin":"4","padding":"0","placeHolder":"ingrese el nombre del alumno","styles":{},"width":"300px"}, {"onchange":"searchUsersDetails"}],
searchBtn: ["wm.Button", {"border":"1","caption":"Buscar","height":"30px","margin":"4","mobileHeight":"30%","showing":false,"styles":{},"width":"110px"}, {"onclick":"searchUsersDetails"}],
spacer3: ["wm.Spacer", {"height":"48px","width":"134px"}, {}],
SecurityComponents: ["wm.Panel", {"height":"35px","horizontalAlign":"center","layoutKind":"left-to-right","styles":{},"verticalAlign":"top","width":"300px"}, {}, {
templateUserNameLabel: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_10px"]},"align":"right","height":"37px","padding":"4","styles":{"fontSize":"9px"},"width":"100%"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"Welcome, \" + ${templateUsernameVar.dataValue}","targetProperty":"caption"}, {}]
}]
}],
templateLogoutButton: ["wm.Button", {"_classes":{"domNode":["wm_FontSizePx_10px"]},"border":"1","borderColor":"#666666","caption":"Salir","height":"30px","iconMargin":"0 20px 0 0","imageIndex":42,"imageList":"app.silkIconList","margin":"2","styles":{}}, {"onclick":"templateLogoutVar"}]
}]
}],
peopledojoGrid1: ["wm.DojoGrid", {"_classes":{"domNode":["Striped"]},"columns":[
{"show":false,"field":"PHONE COLUMN","title":"-","width":"100%","align":"left","expression":"\"<div class='MobileRowTitle'>\" +\n\"Código: \" + ${codigo} +\n\"</div>\"\n\n+ \"<div class='MobileRow'>\" +\n\"Curso: \" + ${curso}\n + \"</div>\"\n\n+ \"<div class='MobileRow'>\" +\n\"Nombre completo: \" + ${fullname}\n + \"</div>\"\n\n+ \"<div class='MobileRow'>\" +\n\"Tipo: \" + ${documento}\n + \"</div>\"\n\n+ \"<div class='MobileRow'>\" +\n\"No. Documento: \" + ${nodocumento}\n + \"</div>\"\n\n","mobileColumn":true},
{"show":false,"field":"idgrupito","title":"Idgrupito","width":"100px","align":"left","formatFunc":"","editorProps":null,"mobileColumn":false},
{"show":true,"field":"codigo","title":"Código","width":"80px","align":"left","formatFunc":"","mobileColumn":false},
{"show":true,"field":"curso","title":"Curso","width":"100px","align":"left","formatFunc":"","mobileColumn":false},
{"show":true,"field":"fullname","title":"Nombre completo","width":"100%","align":"left","formatFunc":"","editorProps":null,"mobileColumn":false},
{"show":true,"field":"documento","title":"Tipo","width":"80px","align":"left","formatFunc":"","mobileColumn":false},
{"show":true,"field":"nodocumento","title":"No. Documento","width":"120px","align":"left","formatProps":{"dijits":0},"editorProps":null,"mobileColumn":false},
{"show":false,"field":"tipo","title":"Tipo","width":"100%","align":"left","formatFunc":"","editorProps":null,"mobileColumn":false},
{"show":false,"field":"year","title":"Year","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"idsy","title":"Idsy","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"idcurso","title":"Idcurso","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"idpersona","title":"Idpersona","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"grupo","title":"Grupo","width":"100%","align":"left","formatFunc":"","mobileColumn":false}
],"dsType":"com.aprendoz_desarrollodb.data.output.GetDetailsUserRtnType","height":"350px","margin":"0","minDesktopHeight":60,"singleClickEdit":true,"styles":{"fontSize":"13px"}}, {"onSelect":"peopledojoGrid1Select","onSelect1":"peopledojoGrid1Select1","onSelect2":"peopledojoGrid1Select2"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"searchUsersDetails","targetProperty":"dataSet"}, {}]
}]
}],
liveFormOuterPanel: ["wm.Panel", {"height":"100%","layoutKind":"left-to-right","padding":"0,10,10,10","styles":{},"width":"100%"}, {}, {
liveFormInnerPanel: ["wm.Panel", {"border":"1","height":"100%","padding":"0,20,20,20","roles":["7","10"],"styles":{"backgroundColor":"#fafafa","borderRadius":"15px"},"width":"100%"}, {}, {
insertLogForm: ["wm.LiveForm", {"height":"233px","horizontalAlign":"center","layoutKind":"left-to-right","styles":{},"verticalAlign":"top"}, {"onError":"errorInsercion","onSuccess":"registroInsertado"}, {
fotoStd: ["wm.Picture", {"aspect":"v","border":"1","borderColor":"#bbb","height":"190px","source":"resources/images/default.png","styles":{},"width":"200px"}, {}],
spacer2: ["wm.Spacer", {"height":"48px","width":"36px"}, {}],
panel1: ["wm.Panel", {"border":"1","borderColor":"#494343","height":"200px","horizontalAlign":"right","margin":"5","padding":"5","styles":{"borderRadius":"5px","backgroundColor":"#ffffff"},"verticalAlign":"top","width":"299px"}, {}, {
tipoSuceso: ["wm.SelectMenu", {"caption":"Evento","captionAlign":"right","dataField":"idTipoFalla","dataType":"com.aprendoz_desarrollodb.data.TipoFalla","dataValue":undefined,"displayField":"tipoFalla","displayValue":"","height":"30px","styles":{},"width":"100%"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"lsTipoSucesos","targetProperty":"dataSet"}, {}]
}]
}],
dateTime1: ["wm.DateTime", {"caption":"Fecha y hora","captionAlign":"right","displayValue":"27/01/2014 08:12 a.m.","emptyValue":"emptyString","height":"30px","readonly":true,"width":"100%"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"new Date().getTime()","targetProperty":"dataValue"}, {}]
}]
}],
spacer1: ["wm.Spacer", {"height":"100%","width":"96px"}, {}],
Registrar_Suceso: ["wm.Button", {"_classes":{"domNode":["Success"]},"border":"1","borderColor":"#51a351","caption":"Registrar","desktopHeight":"38px","disabled":true,"height":"38px"}, {"onclick":"Registrar_SucesoClick","onclick1":"Registrar_SucesoClick1"}]
}]
}]
}]
}]
}]
}]
};

Main.prototype._cssText = '#main_fotoStd {\
border-radius: 50%;\
background-color: darkgrey;\
width: 194px !important;\
}\
#main_peopledojoGrid1{\
cursor: pointer;\
}\
';
Main.prototype._htmlText = '';