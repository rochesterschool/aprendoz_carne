
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.InscripcionesVistaInscAlumnCurso
 *  01/24/2014 10:11:19
 * 
 */
public class InscripcionesVistaInscAlumnCurso {

    private InscripcionesVistaInscAlumnCursoId id;

    public InscripcionesVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(InscripcionesVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
