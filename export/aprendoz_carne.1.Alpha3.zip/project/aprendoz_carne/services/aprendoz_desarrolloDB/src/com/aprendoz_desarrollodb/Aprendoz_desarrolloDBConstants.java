
package com.aprendoz_desarrollodb;



/**
 *  Query names for service "aprendoz_desarrolloDB"
 *  01/27/2014 09:37:53
 * 
 */
public class Aprendoz_desarrolloDBConstants {

    public final static String getDetailsUserQueryName = "getDetailsUser";
    public final static String getTipoPersonaByIdQueryName = "getTipoPersonaById";
    public final static String orientacionInvolucradosGrupoFamiliarQueryName = "orientacionInvolucradosGrupoFamiliar";

}
