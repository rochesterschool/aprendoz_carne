
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DirectoresDocentesListadoReportes
 *  01/24/2014 10:11:19
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}
