
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.CurriculoGrado
 *  01/24/2014 10:11:19
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}
