
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VProfesorAsignaturaCompleto
 *  01/24/2014 10:11:19
 * 
 */
public class VProfesorAsignaturaCompleto {

    private VProfesorAsignaturaCompletoId id;

    public VProfesorAsignaturaCompletoId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

}
