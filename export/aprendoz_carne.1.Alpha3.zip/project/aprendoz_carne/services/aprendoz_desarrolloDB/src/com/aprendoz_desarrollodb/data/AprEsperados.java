
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AprEsperados
 *  01/24/2014 10:11:19
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
