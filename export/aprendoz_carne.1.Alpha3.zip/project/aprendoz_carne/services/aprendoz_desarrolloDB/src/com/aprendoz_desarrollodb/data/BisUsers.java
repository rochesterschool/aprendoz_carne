
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.BisUsers
 *  01/24/2014 10:11:19
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}
