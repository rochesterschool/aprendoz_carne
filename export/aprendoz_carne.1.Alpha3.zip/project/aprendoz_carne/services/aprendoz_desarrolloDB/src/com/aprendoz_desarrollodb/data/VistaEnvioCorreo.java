
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaEnvioCorreo
 *  01/24/2014 10:11:19
 * 
 */
public class VistaEnvioCorreo {

    private VistaEnvioCorreoId id;

    public VistaEnvioCorreoId getId() {
        return id;
    }

    public void setId(VistaEnvioCorreoId id) {
        this.id = id;
    }

}
