
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.CalifEst
 *  01/24/2014 10:11:19
 * 
 */
public class CalifEst {

    private CalifEstId id;

    public CalifEstId getId() {
        return id;
    }

    public void setId(CalifEstId id) {
        this.id = id;
    }

}
