
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Vistaasistencia
 *  01/24/2014 10:11:19
 * 
 */
public class Vistaasistencia {

    private VistaasistenciaId id;

    public VistaasistenciaId getId() {
        return id;
    }

    public void setId(VistaasistenciaId id) {
        this.id = id;
    }

}
