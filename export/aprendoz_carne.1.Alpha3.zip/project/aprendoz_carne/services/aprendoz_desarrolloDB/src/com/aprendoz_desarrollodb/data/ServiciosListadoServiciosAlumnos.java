
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.ServiciosListadoServiciosAlumnos
 *  01/24/2014 10:11:19
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}
