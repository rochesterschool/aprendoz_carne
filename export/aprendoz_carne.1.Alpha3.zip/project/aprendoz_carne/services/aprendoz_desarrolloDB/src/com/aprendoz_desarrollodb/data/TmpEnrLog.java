
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.TmpEnrLog
 *  01/24/2014 10:11:19
 * 
 */
public class TmpEnrLog {

    private TmpEnrLogId id;

    public TmpEnrLogId getId() {
        return id;
    }

    public void setId(TmpEnrLogId id) {
        this.id = id;
    }

}
