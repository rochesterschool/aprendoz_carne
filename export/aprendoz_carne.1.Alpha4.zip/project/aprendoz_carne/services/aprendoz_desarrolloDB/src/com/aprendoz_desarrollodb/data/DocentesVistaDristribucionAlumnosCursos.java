
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesVistaDristribucionAlumnosCursos
 *  01/24/2014 10:11:19
 * 
 */
public class DocentesVistaDristribucionAlumnosCursos {

    private DocentesVistaDristribucionAlumnosCursosId id;

    public DocentesVistaDristribucionAlumnosCursosId getId() {
        return id;
    }

    public void setId(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

}
