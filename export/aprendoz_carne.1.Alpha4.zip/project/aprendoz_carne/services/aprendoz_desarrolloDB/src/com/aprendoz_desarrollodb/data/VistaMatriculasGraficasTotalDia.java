
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaMatriculasGraficasTotalDia
 *  01/24/2014 10:11:19
 * 
 */
public class VistaMatriculasGraficasTotalDia {

    private VistaMatriculasGraficasTotalDiaId id;

    public VistaMatriculasGraficasTotalDiaId getId() {
        return id;
    }

    public void setId(VistaMatriculasGraficasTotalDiaId id) {
        this.id = id;
    }

}
