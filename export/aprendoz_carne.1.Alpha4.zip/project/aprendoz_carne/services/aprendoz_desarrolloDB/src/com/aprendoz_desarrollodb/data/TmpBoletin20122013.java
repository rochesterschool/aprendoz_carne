
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.TmpBoletin20122013
 *  01/24/2014 10:11:19
 * 
 */
public class TmpBoletin20122013 {

    private TmpBoletin20122013Id id;

    public TmpBoletin20122013Id getId() {
        return id;
    }

    public void setId(TmpBoletin20122013Id id) {
        this.id = id;
    }

}
