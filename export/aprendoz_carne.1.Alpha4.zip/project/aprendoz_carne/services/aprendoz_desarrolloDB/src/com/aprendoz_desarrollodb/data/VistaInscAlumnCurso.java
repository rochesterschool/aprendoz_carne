
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaInscAlumnCurso
 *  01/24/2014 10:11:19
 * 
 */
public class VistaInscAlumnCurso {

    private VistaInscAlumnCursoId id;

    public VistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(VistaInscAlumnCursoId id) {
        this.id = id;
    }

}
