
package com.aprendoz_desarrollodb;



/**
 *  Query names for service "aprendoz_desarrolloDB"
 *  02/12/2014 11:23:25
 * 
 */
public class Aprendoz_desarrolloDBConstants {

    public final static String getDetailsUserQueryName = "getDetailsUser";
    public final static String getTipoPersonaByIdQueryName = "getTipoPersonaById";
    public final static String orientacionInvolucradosGrupoFamiliarQueryName = "orientacionInvolucradosGrupoFamiliar";

}
