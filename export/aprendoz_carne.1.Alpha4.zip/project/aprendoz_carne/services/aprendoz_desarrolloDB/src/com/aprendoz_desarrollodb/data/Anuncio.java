
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Anuncio
 *  01/24/2014 10:11:19
 * 
 */
public class Anuncio {

    private String anuncio;

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
