
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaPersonasGrupoFamiliar
 *  01/24/2014 10:11:19
 * 
 */
public class VistaPersonasGrupoFamiliar {

    private VistaPersonasGrupoFamiliarId id;

    public VistaPersonasGrupoFamiliarId getId() {
        return id;
    }

    public void setId(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

}
