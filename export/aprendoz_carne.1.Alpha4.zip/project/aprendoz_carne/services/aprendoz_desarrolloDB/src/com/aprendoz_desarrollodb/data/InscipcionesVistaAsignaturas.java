
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.InscipcionesVistaAsignaturas
 *  01/24/2014 10:11:19
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}
