
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesVistaCalificacionFinal
 *  01/24/2014 10:11:19
 * 
 */
public class DocentesVistaCalificacionFinal {

    private DocentesVistaCalificacionFinalId id;

    public DocentesVistaCalificacionFinalId getId() {
        return id;
    }

    public void setId(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

}
