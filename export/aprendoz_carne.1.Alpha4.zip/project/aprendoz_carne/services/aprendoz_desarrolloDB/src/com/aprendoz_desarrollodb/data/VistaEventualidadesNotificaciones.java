
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaEventualidadesNotificaciones
 *  01/24/2014 10:11:19
 * 
 */
public class VistaEventualidadesNotificaciones {

    private VistaEventualidadesNotificacionesId id;

    public VistaEventualidadesNotificacionesId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesId id) {
        this.id = id;
    }

}
