
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.CafeteriaProteina
 *  01/24/2014 10:11:19
 * 
 */
public class CafeteriaProteina {

    private Integer idProteinas;
    private String proteina;
    private String descripcion;
    private String imageLink;

    public Integer getIdProteinas() {
        return idProteinas;
    }

    public void setIdProteinas(Integer idProteinas) {
        this.idProteinas = idProteinas;
    }

    public String getProteina() {
        return proteina;
    }

    public void setProteina(String proteina) {
        this.proteina = proteina;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

}
