
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaAlumnosActivosPrejardinNuevos
 *  01/24/2014 10:11:19
 * 
 */
public class VistaAlumnosActivosPrejardinNuevos {

    private VistaAlumnosActivosPrejardinNuevosId id;

    public VistaAlumnosActivosPrejardinNuevosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosPrejardinNuevosId id) {
        this.id = id;
    }

}
