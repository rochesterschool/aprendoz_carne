dojo.declare("Main", wm.Page, {
	start: function() {
		
	},
	"preferredDevice": "desktop",
    // shwo picture
	peopledojoGrid1Select: function(inSender) {
		var codigop= this.peopledojoGrid1.selectedItem.data.codigo;
        this.fotoStd.setSource("http://www.rochester.edu.co/fotosestudiantes/"+codigop+".Jpeg");
	},
    //save suceso
	Registrar_SucesoClick: function(inSender) {
		var idpersona= this.peopledojoGrid1.selectedItem.data.idpersona;
        var tipo= this.tipoSuceso.getDataValue();
        var now = new Date().getTime();
        debugger;
        this.varInsertLog.setValue("persona.idPersona", idpersona);
        this.varInsertLog.setValue("tipoFalla.idTipoFalla", tipo);
        this.varInsertLog.setValue("fechaCreacion", now);
        debugger;
        this.insertLogForm.setDataSet(this.varInsertLog); 
        this.insertLogForm.insertData(); 
        debugger;
	},
    
    
	_end: 0
});