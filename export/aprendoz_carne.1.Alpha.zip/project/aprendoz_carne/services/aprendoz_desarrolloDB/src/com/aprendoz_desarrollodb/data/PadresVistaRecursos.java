
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.PadresVistaRecursos
 *  01/24/2014 10:11:19
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
