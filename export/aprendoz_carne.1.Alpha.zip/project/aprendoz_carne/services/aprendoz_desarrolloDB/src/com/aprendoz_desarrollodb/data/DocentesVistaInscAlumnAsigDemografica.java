
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesVistaInscAlumnAsigDemografica
 *  01/24/2014 10:11:19
 * 
 */
public class DocentesVistaInscAlumnAsigDemografica {

    private DocentesVistaInscAlumnAsigDemograficaId id;

    public DocentesVistaInscAlumnAsigDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigDemograficaId id) {
        this.id = id;
    }

}
