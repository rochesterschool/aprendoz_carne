
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaDashboardNoCalificados
 *  01/24/2014 10:11:19
 * 
 */
public class VistaDashboardNoCalificados {

    private VistaDashboardNoCalificadosId id;

    public VistaDashboardNoCalificadosId getId() {
        return id;
    }

    public void setId(VistaDashboardNoCalificadosId id) {
        this.id = id;
    }

}
