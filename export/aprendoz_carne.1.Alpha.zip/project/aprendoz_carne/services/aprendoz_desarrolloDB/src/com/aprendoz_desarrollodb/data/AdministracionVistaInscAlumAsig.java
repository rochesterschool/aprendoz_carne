
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AdministracionVistaInscAlumAsig
 *  01/24/2014 10:11:19
 * 
 */
public class AdministracionVistaInscAlumAsig {

    private AdministracionVistaInscAlumAsigId id;

    public AdministracionVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumAsigId id) {
        this.id = id;
    }

}
