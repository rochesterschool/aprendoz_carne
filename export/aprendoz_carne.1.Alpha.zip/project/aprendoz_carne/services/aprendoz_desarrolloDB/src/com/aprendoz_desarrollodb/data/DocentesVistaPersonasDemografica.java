
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesVistaPersonasDemografica
 *  01/24/2014 10:11:19
 * 
 */
public class DocentesVistaPersonasDemografica {

    private DocentesVistaPersonasDemograficaId id;

    public DocentesVistaPersonasDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

}
