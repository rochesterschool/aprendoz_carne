
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Anticipos
 *  01/24/2014 10:11:19
 * 
 */
public class Anticipos {

    private Integer idAnticipos;
    private String codigo;

    public Integer getIdAnticipos() {
        return idAnticipos;
    }

    public void setIdAnticipos(Integer idAnticipos) {
        this.idAnticipos = idAnticipos;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

}
