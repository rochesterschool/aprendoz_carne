
package com.aprendoz_desarrollodb;



/**
 *  Query names for service "aprendoz_desarrolloDB"
 *  01/24/2014 10:19:51
 * 
 */
public class Aprendoz_desarrolloDBConstants {

    public final static String getDetailsUserQueryName = "getDetailsUser";
    public final static String getTipoPersonaByIdQueryName = "getTipoPersonaById";

}
