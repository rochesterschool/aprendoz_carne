
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.PromocionVistaInscAlumnCurso
 *  01/24/2014 10:11:19
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
