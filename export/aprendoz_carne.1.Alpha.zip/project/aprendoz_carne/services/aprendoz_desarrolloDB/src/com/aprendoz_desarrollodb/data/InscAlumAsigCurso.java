
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.InscAlumAsigCurso
 *  01/24/2014 10:11:19
 * 
 */
public class InscAlumAsigCurso {

    private InscAlumAsigCursoId id;

    public InscAlumAsigCursoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoId id) {
        this.id = id;
    }

}
