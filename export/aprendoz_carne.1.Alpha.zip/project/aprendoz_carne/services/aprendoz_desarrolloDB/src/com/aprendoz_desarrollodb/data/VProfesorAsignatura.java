
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VProfesorAsignatura
 *  01/24/2014 10:11:19
 * 
 */
public class VProfesorAsignatura {

    private VProfesorAsignaturaId id;

    public VProfesorAsignaturaId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaId id) {
        this.id = id;
    }

}
