
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesInicioVistaDetallesAcceso
 *  01/24/2014 10:11:19
 * 
 */
public class DocentesInicioVistaDetallesAcceso {

    private DocentesInicioVistaDetallesAccesoId id;

    public DocentesInicioVistaDetallesAccesoId getId() {
        return id;
    }

    public void setId(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

}
