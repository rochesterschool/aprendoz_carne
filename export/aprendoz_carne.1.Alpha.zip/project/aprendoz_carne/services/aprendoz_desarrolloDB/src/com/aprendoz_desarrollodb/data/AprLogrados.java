
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AprLogrados
 *  01/24/2014 10:11:19
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
